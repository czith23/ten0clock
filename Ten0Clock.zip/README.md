Ten0clock, Make the most of your night 
==========================

Peak inside the front door of your favorite restaurant, pub, or concert hall from the comfort of your couch. Ten0clock is an Android utility that surveys nearby venues and gives accurate, real-time descriptions of the action inside.

Check wait-times, menus, crowds, house bands, events, or specials. Ten0clock allows users to post to venue specific chatrooms developing a live review board. Look at what entres your friends have been eating or the bars they've been frequenting.

With Ten0clock you can schedule public or private events and post them to a venue's calendar. Plan game nights, company happy hours, and more. Never leave a crowded restaurant again; Ten0clock makes it easy to enjoy a night on the town your way. 
