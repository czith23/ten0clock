/** Automatically generated file. DO NOT MODIFY */
package ten0clock.gui.pages;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}