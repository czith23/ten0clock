package ten0clock.gui.pages;

import android.app.Fragment;

//TODO: Implement SettingsFragment
public class SettingsFragment extends Fragment {

}
