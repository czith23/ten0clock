package ten0clock.gui.pages;

import android.app.Fragment;

public class PollDetailFragment extends Fragment {

}
