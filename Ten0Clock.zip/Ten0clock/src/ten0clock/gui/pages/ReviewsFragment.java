package ten0clock.gui.pages;

import android.app.Fragment;


//TODO: Implement ReviewsFragment
public class ReviewsFragment extends Fragment {

}
