package ten0clock.backend.account;

/*
 * Used to manage, authenticate, and create accounts
 */
public class Ten0ClockAccount {
	private String firstName;
	private String lastName;
	private String userID;
	private String password;
	private String email;
	private String phoneNumber;
	private String school;
	
	public Ten0ClockAccount() {
		
	}
	
	public void addToDB() {
		
	}
	
	public boolean isValidAccount() {
		return false;
	}
	
	public boolean isNewAccount() {
		return false;
	}
}
