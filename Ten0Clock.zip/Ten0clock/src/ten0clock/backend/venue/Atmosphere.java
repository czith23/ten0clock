package ten0clock.backend.venue;

public class Atmosphere {

	public static final int EMPTY = 1;
	public static final int RELAXED = 2;
	public static final int MODERATE = 3;
	public static final int LOUD = 4;
	public static final int DANGEROUS = 5;
}
